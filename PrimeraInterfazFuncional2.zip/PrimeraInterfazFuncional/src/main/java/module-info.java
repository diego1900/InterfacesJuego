module com.bsalido.primerainterfazfuncional {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.bsalido.primerainterfazfuncional to javafx.fxml;
    exports com.bsalido.primerainterfazfuncional;
}