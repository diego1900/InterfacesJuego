module com.dblanco.interfaces {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.graphics;


    opens com.dblanco.interfaces to javafx.fxml;
    exports com.dblanco.interfaces;
}