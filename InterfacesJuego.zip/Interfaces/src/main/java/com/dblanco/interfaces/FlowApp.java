package com.dblanco.interfaces;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;



public class FlowApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        //Crear 6 Botones
        Button bt1 = new Button("Botón 1");
        Button bt2 = new Button("Botón 2");
        Button bt3 = new Button("Botón 3");
        Button bt4 = new Button("Botón 4");
        Button bt5 = new Button("Botón 5");
        Button bt6 = new Button("Botón 6");

        FlowPane root = new FlowPane();
        root.getChildren().addAll(bt1, bt2, bt3, bt4, bt5, bt6); //Aquí van todos los componentes de arriba
        root.setAlignment(Pos.CENTER);
    }
}
