package com.dblanco.interfaces;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class App extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    private static Scene scene;
    @Override
    public void start(Stage stage) {
        BorderPane root = new BorderPane();

        //Botón1
        Button bt1 = new Button("Encabezado");
        bt1.setMaxWidth(Double.MAX_VALUE);
        bt1.setMaxHeight(Double.MAX_VALUE);
        root.setTop(bt1);

        //Botón2
        Button bt2 = new Button("Encabezado");
        bt1.setMaxWidth(Double.MAX_VALUE);
        bt1.setMaxHeight(Double.MAX_VALUE);
        root.setBottom(bt2);

        //Botón3
        Button bt3 = new Button("Encabezado");
        bt1.setMaxWidth(Double.MAX_VALUE);
        bt1.setMaxHeight(Double.MAX_VALUE);
        root.setRight(bt3);

        //Botón4
        Button bt4 = new Button("Encabezado");
        bt1.setMaxWidth(Double.MAX_VALUE);
        bt1.setMaxHeight(Double.MAX_VALUE);
        root.setLeft(bt4);

        //Botón5
        Button bt5 = new Button("Encabezado");
        bt1.setMaxWidth(Double.MAX_VALUE);
        bt1.setMaxHeight(Double.MAX_VALUE);
        root.setCenter(bt5);

// AÑADE AQUÍ LOS OTROS CUATRO BOTONES: CENTER, BOTTOM, RIGHT y LEFT
        scene = new Scene(root, 300, 250);
        stage.setScene(scene);
        stage.show();


        //Dar MÁRGENES
        BorderPane.setMargin(bt1, new Insets(5,5,5,5));


    }
}
