package com.dblanco.interfaces;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class VBoxApp extends Application {

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) {

        Label label = new Label("LOGIN DAM");
        Label label2 = new Label("Usuario");
        TextField txf = new TextField();
        Label label3 = new Label("Contraseña");
        PasswordField passwd = new PasswordField();
        Button bt1 = new Button("Entrar");


        VBox root = new VBox();
        root.getChildren().addAll(label, label2, txf, label3, passwd, bt1); //Aquí van todos los componentes de arriba
        root.setAlignment (Pos.CENTER);
        VBox.setMargin (label , new Insets(10,0,0,0));
        VBox.setMargin (label2 , new Insets(35,0,0,0));
        VBox.setMargin (txf , new Insets(5,0,0,0));
        VBox.setMargin (label3 , new Insets(10,0,0,0));
        VBox.setMargin (passwd , new Insets(5,0,0,0));
        VBox.setMargin (bt1 , new Insets(0,0,0,0));

        Scene scene = new Scene(root, 300, 250);
        stage.setScene(scene);
        stage.show();
    }
}
