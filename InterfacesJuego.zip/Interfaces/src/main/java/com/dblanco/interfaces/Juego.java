package com.dblanco.interfaces;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Juego extends Application {

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage){

        //Resto del ejercicio (Todo menos los botones)
        VBox root = new VBox();


        int numIntentos;
        Label label = new Label("JUEGO ADIVINAR NÚMEROS");
        Label label2 = new Label("Intenta adivinar el número");
        TextField txf = new TextField();




        //Layout Botones
        BorderPane rootBotones = new BorderPane();
        Button bt1 = new Button("Entrar");
        bt1.setMaxWidth(Double.MAX_VALUE);
        bt1.setMaxHeight(Double.MAX_VALUE);
        rootBotones.setCenter(bt1);

        Button bt2 = new Button("Reiniciar");
        bt1.setMaxWidth(Double.MAX_VALUE);
        bt1.setMaxHeight(Double.MAX_VALUE);
        rootBotones.setCenter(bt2);


        root.getChildren().addAll(label, label2, txf, rootBotones);



        Scene scene = new Scene(root, 300, 250);
        stage.setScene(scene);
        stage.show();
    }
}
